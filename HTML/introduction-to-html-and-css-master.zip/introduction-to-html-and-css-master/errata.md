# Errata for *Introduction to HTML and CSS*

On **time stamp** [Summary of error]:
 
Details of error here. Highlight key pieces in **bold**.

***

On **time stamp** [Summary of error]:
 
Details of error here. Highlight key pieces in **bold**.

***